<?php

namespace App\Livewire;

use Livewire\Component;

class GrupoEconomico extends Component
{
    public function render()
    {
        return view('livewire.grupo-economico');
    }
}
